# Installation
> `npm install --save @types/bytebuffer`

# Summary
This package contains type definitions for bytebuffer.js (https://github.com/dcodeIO/bytebuffer.js).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/bytebuffer

Additional Details
 * Last updated: Thu, 22 Mar 2018 17:52:41 GMT
 * Dependencies: long, node
 * Global values: ByteBuffer

# Credits
These definitions were written by Denis Cappellin <https://github.com/cappellin>.
