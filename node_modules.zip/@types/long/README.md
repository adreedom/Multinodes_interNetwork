# Installation
> `npm install --save @types/long`

# Summary
This package contains type definitions for long.js (https://github.com/dcodeIO/long.js).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/long

Additional Details
 * Last updated: Wed, 25 Apr 2018 00:38:11 GMT
 * Dependencies: none
 * Global values: Long

# Credits
These definitions were written by Peter Kooijmans <https://github.com/peterkooijmans>.
