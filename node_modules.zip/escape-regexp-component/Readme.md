
# escape-regexp

  Escape regular expression special characters.

## Example

```js
var escape = require('escape-regexp');
escape(str);
```

## License

  MIT