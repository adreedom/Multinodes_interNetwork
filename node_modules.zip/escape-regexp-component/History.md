
1.0.1/ 2012-11-28 
==================

  * fix package.json again

1.0.0 / 2012-11-28 
==================

  * fix package.json
