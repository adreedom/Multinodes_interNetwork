module.exports = require("./dist/protobuf.js");
