# path

This is an exact copy of the NodeJS ’path’ module published to the NPM registry. 

[Documentation](http://nodejs.org/docs/latest/api/path.html)

## Install

```sh
$ npm install --save path
```

## License

MIT
