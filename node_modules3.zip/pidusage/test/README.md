#Test section

## test.js

Run this one first. `mocha test`

## server.js

Used to be tested with an HTTP benchmark tool like this one: https://github.com/wg/wrk.

Start the server, run the tests on `localhost:8020`

## stresstest.js

Just start node stresstest.js (but be carefull though...)